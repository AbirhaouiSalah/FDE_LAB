#!/usr/bin/env bash
# scripts/lots/build-all.sh
# Orchestre les 7 lots (L1..L7) dans l'ordre.
#
# Usage:
#   ./scripts/lots/build-all.sh [--from N] [--to N]
#                                [--dry-run] [--no-push]
#                                [--no-propagate] [--no-tests] [--yes]
#                                [--stop-on-failure]
#
# Exemples:
#   ./scripts/lots/build-all.sh                    # L1..L7, demande confirmation
#   ./scripts/lots/build-all.sh --yes              # L1..L7, sans confirmation
#   ./scripts/lots/build-all.sh --from 2 --to 4    # L2..L4 seulement
#   ./scripts/lots/build-all.sh --dry-run          # tout en dry-run

set -euo pipefail

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT="$(cd "$DIR/../.." && pwd)"
cd "$ROOT"

# ─────────────────────────────────────────────────────────────
# Couleurs
# ─────────────────────────────────────────────────────────────
if [[ -t 1 ]]; then
  C_RED=$'\033[0;31m'; C_GRN=$'\033[0;32m'; C_YEL=$'\033[0;33m'
  C_BLU=$'\033[0;34m'; C_DIM=$'\033[2m';    C_RST=$'\033[0m'
else
  C_RED=""; C_GRN=""; C_YEL=""; C_BLU=""; C_DIM=""; C_RST=""
fi

master_log()  { printf '%s[all]%s %s\n' "$C_BLU" "$C_RST" "$*"; }
master_ok()   { printf '%s[ok ]%s %s\n' "$C_GRN" "$C_RST" "$*"; }
master_warn() { printf '%s[wrn]%s %s\n' "$C_YEL" "$C_RST" "$*" >&2; }
master_die()  { printf '%s[err]%s %s\n' "$C_RED" "$C_RST" "$*" >&2; exit 1; }

# ─────────────────────────────────────────────────────────────
# Args
# ─────────────────────────────────────────────────────────────
FROM=1
TO=7
STOP_ON_FAILURE=0
PASSTHROUGH=()

while [[ $# -gt 0 ]]; do
  case "$1" in
    --from)             FROM="${2:-1}"; shift 2 ;;
    --to)               TO="${2:-7}"; shift 2 ;;
    --stop-on-failure)  STOP_ON_FAILURE=1; shift ;;
    --dry-run|--no-push|--no-propagate|--no-tests|--yes|-y)
      PASSTHROUGH+=("$1"); shift ;;
    -h|--help)
      sed -n '2,18p' "$0"
      exit 0
      ;;
    *) master_die "unexpected arg: $1" ;;
  esac
done

[[ "$FROM" =~ ^[1-7]$ ]] || master_die "--from must be 1..7 (got: $FROM)"
[[ "$TO"   =~ ^[1-7]$ ]] || master_die "--to must be 1..7 (got: $TO)"
[[ "$FROM" -le "$TO" ]]  || master_die "--from must be <= --to"

# ─────────────────────────────────────────────────────────────
# Pre-flight
# ─────────────────────────────────────────────────────────────
git rev-parse --is-inside-work-tree >/dev/null 2>&1 || master_die "not a git repo"

if [[ ! -f "$DIR/build-lot-1.sh" ]]; then
  master_die "missing build-lot-1.sh in $DIR"
fi

master_log "orchestrating lots L${FROM}..L${TO}"
master_log "passthrough flags: ${PASSTHROUGH[*]:-<none>}"

# ─────────────────────────────────────────────────────────────
# Exécution séquentielle
# ─────────────────────────────────────────────────────────────
declare -a RESULTS=()
declare -a FAILED_LOTS=()

for n in $(seq "$FROM" "$TO"); do
  SCRIPT="$DIR/build-lot-${n}.sh"

  if [[ ! -x "$SCRIPT" ]]; then
    master_warn "L${n}: script not found or not executable ($SCRIPT)"
    RESULTS+=("L${n}:SKIP")
    continue
  fi

  echo
  printf '%s════════════════════════════════════════════════════════════%s\n' "$C_BLU" "$C_RST"
  master_log "▶▶▶ Starting L${n} — $SCRIPT"
  printf '%s════════════════════════════════════════════════════════════%s\n' "$C_BLU" "$C_RST"

  set +e
  "$SCRIPT" ${PASSTHROUGH[@]+"${PASSTHROUGH[@]}"}
  rc=$?
  set -e

  if [[ $rc -eq 0 ]]; then
    master_ok "L${n} — complete"
    RESULTS+=("L${n}:OK")
  else
    master_warn "L${n} — failed (rc=$rc)"
    RESULTS+=("L${n}:FAIL")
    FAILED_LOTS+=("L${n}")

    if [[ "$STOP_ON_FAILURE" == "1" ]]; then
      master_die "stopping after L${n} failure (--stop-on-failure)"
    fi
  fi
done

# ─────────────────────────────────────────────────────────────
# Résumé final
# ─────────────────────────────────────────────────────────────
echo
printf '%s════════════════════════════════════════════════════════════%s\n' "$C_BLU" "$C_RST"
master_log "SUMMARY"
printf '%s════════════════════════════════════════════════════════════%s\n' "$C_BLU" "$C_RST"
for r in "${RESULTS[@]}"; do
  case "$r" in
    *:OK)   printf '  %s%s%s\n' "$C_GRN" "$r" "$C_RST" ;;
    *:FAIL) printf '  %s%s%s\n' "$C_RED" "$r" "$C_RST" ;;
    *:SKIP) printf '  %s%s%s\n' "$C_YEL" "$r" "$C_RST" ;;
    *)      printf '  %s\n' "$r" ;;
  esac
done

echo
if [[ "${#FAILED_LOTS[@]}" -eq 0 ]]; then
  master_ok "all lots completed successfully"
  exit 0
else
  master_warn "${#FAILED_LOTS[@]} lot(s) failed: ${FAILED_LOTS[*]}"
  exit 1
fi
