#!/usr/bin/env bash
# scripts/lots/build-lot-2.sh
# L2 — Widgets RGPD & Data : SmallGroupGuard + KpiCard + QueueTable + AlertPanel
# Branche pivot : ats-lab/comp/widgets/small-group-guard

set -euo pipefail
source "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/_lib.sh"

LOT_TAG="L2"; export LOT_TAG
PIVOT="ats-lab/comp/widgets/small-group-guard"
SUBS=(
  "ats-lab/comp/widgets/small-group-guard|src/widgets/SmallGroupGuard/"
  "ats-lab/comp/widgets/kpi-card|src/widgets/KpiCard/"
  "ats-lab/comp/widgets/queue-table|src/widgets/QueueTable/"
  "ats-lab/comp/widgets/alert-panel|src/widgets/AlertPanel/"
)

parse_common_flags "$@"; shift $?
check_prereqs
ensure_branch "$PIVOT"

section "L2 · Widgets RGPD & Data — écriture des artefacts"

# ---------- SmallGroupGuard ----------
write_file "$REPO_ROOT/src/widgets/SmallGroupGuard/SmallGroupGuard.tsx" <<'EOF'
// src/widgets/SmallGroupGuard/SmallGroupGuard.tsx
// Garde RGPD : masque tout agrégat dont l'effectif n < k. Fail-closed.
import { type ReactNode } from "react";
import { useTranslation } from "react-i18next";
import styles from "./SmallGroupGuard.module.css";

export interface SmallGroupGuardProps {
  n: number | null | undefined;
  k?: number;                          // défaut 5 (recommandation CNIL)
  children: ReactNode;
  maskedMessage?: ReactNode;
  label?: string;                      // traçabilité
}

export function SmallGroupGuard({ n, k = 5, children, maskedMessage, label }: SmallGroupGuardProps) {
  const { t } = useTranslation();
  const safe = typeof n === "number" && Number.isFinite(n) && Number.isInteger(n) && n >= k;

  if (safe) return <>{children}</>;

  const suppressed = typeof n === "number" && Number.isFinite(n) ? Math.max(0, n) : "unknown";
  return (
    <div
      className={styles.masked}
      role="status"
      aria-live="polite"
      data-testid="small-group-guard-masked"
      data-suppressed-count={suppressed}
      data-guard-k={k}
      data-guard-label={label ?? ""}
    >
      {maskedMessage ?? (
        <>
          <span className={styles.icon} aria-hidden="true">🔒</span>
          <span className={styles.text}>{t("rgpd.smallGroup.masked", { k })}</span>
        </>
      )}
    </div>
  );
}
EOF

write_file "$REPO_ROOT/src/widgets/SmallGroupGuard/SmallGroupGuard.module.css" <<'EOF'
.masked {
  display: flex; align-items: center; gap: 0.5rem;
  padding: 0.75rem 1rem;
  border: 1px dashed var(--color-border-muted, #cbd5e1);
  border-radius: 8px;
  background: var(--color-bg-muted, #f8fafc);
  color: var(--color-text-muted, #64748b);
  font-size: 0.875rem; font-style: italic;
}
.icon { flex: 0 0 auto; }
.text { flex: 1 1 auto; }
EOF

write_file "$REPO_ROOT/src/widgets/SmallGroupGuard/index.ts" <<'EOF'
export { SmallGroupGuard } from "./SmallGroupGuard";
export type { SmallGroupGuardProps } from "./SmallGroupGuard";
EOF

# ---------- KpiCard ----------
write_file "$REPO_ROOT/src/widgets/KpiCard/KpiCard.tsx" <<'EOF'
// src/widgets/KpiCard/KpiCard.tsx — carte KPI présentationnelle, gardée RGPD.
import { useTranslation } from "react-i18next";
import { SmallGroupGuard } from "../SmallGroupGuard";
import styles from "./KpiCard.module.css";

export type Confidence = "low" | "medium" | "high";

export interface KpiCardProps {
  labelKey: string;
  value: number | null;
  n?: number | null;
  k?: number;
  unit?: string;
  confidence?: Confidence;
  forceMask?: boolean;
  trend?: "up" | "down" | "flat";
  traceLabel?: string;
}

function formatValue(v: number | null, unit?: string): string {
  if (v === null || !Number.isFinite(v)) return "—";
  const base = Number.isInteger(v) ? v.toLocaleString("fr-FR") : v.toFixed(2);
  return unit ? `${base}${unit.startsWith("%") ? unit : ` ${unit}`}` : base;
}

export function KpiCard({ labelKey, value, n, k = 5, unit, confidence, forceMask = false, trend, traceLabel }: KpiCardProps) {
  const { t } = useTranslation();
  const content = (
    <div className={styles.card} data-testid="kpi-card">
      <div className={styles.header}>
        <span className={styles.label}>{t(labelKey)}</span>
        {confidence && (
          <span className={`${styles.badge} ${styles[`conf_${confidence}`]}`} data-testid="kpi-confidence">
            {t(`kpi.confidence.${confidence}`)}
          </span>
        )}
      </div>
      <div className={styles.value} data-testid="kpi-value">
        {formatValue(value, unit)}
        {trend && (
          <span className={`${styles.trend} ${styles[`trend_${trend}`]}`} aria-hidden="true">
            {trend === "up" ? "▲" : trend === "down" ? "▼" : "■"}
          </span>
        )}
      </div>
      <div className={styles.disclaimer} data-testid="kpi-disclaimer">{t("footer.readonly")}</div>
    </div>
  );

  if (forceMask) {
    return (
      <div className={styles.card} data-testid="kpi-card" data-force-masked="true">
        <div className={styles.header}><span className={styles.label}>{t(labelKey)}</span></div>
        <SmallGroupGuard n={-1} k={k} label={traceLabel}>{content}</SmallGroupGuard>
      </div>
    );
  }
  return <SmallGroupGuard n={n} k={k} label={traceLabel}>{content}</SmallGroupGuard>;
}
EOF

write_file "$REPO_ROOT/src/widgets/KpiCard/KpiCard.module.css" <<'EOF'
.card { display:flex; flex-direction:column; gap:.5rem; padding:1rem 1.25rem;
  border:1px solid var(--color-border,#e2e8f0); border-radius:12px; background:var(--color-bg,#fff); min-width:180px; }
.header { display:flex; align-items:center; justify-content:space-between; gap:.5rem; }
.label { font-size:.8125rem; font-weight:500; color:var(--color-text-muted,#64748b); text-transform:uppercase; letter-spacing:.02em; }
.value { font-size:1.75rem; font-weight:700; color:var(--color-text,#0f172a); display:flex; align-items:baseline; gap:.5rem; }
.badge { font-size:.6875rem; font-weight:600; padding:.125rem .5rem; border-radius:999px; text-transform:uppercase; letter-spacing:.02em; }
.conf_low{background:#fee2e2;color:#991b1b}.conf_medium{background:#fef3c7;color:#92400e}.conf_high{background:#dcfce7;color:#166534}
.trend{font-size:.875rem}.trend_up{color:#16a34a}.trend_down{color:#dc2626}.trend_flat{color:#94a3b8}
.disclaimer{font-size:.6875rem;color:var(--color-text-muted,#94a3b8);font-style:italic}
EOF

write_file "$REPO_ROOT/src/widgets/KpiCard/index.ts" <<'EOF'
export { KpiCard } from "./KpiCard";
export type { KpiCardProps, Confidence } from "./KpiCard";
EOF

# ---------- QueueTable ----------
write_file "$REPO_ROOT/src/widgets/QueueTable/QueueTable.tsx" <<'EOF'
// src/widgets/QueueTable/QueueTable.tsx — file pseudonymisée, aucun PII, aucune décision.
import { useMemo } from "react";
import { useTranslation } from "react-i18next";
import { SmallGroupGuard } from "../SmallGroupGuard";
import styles from "./QueueTable.module.css";

export type QueueStatus = "pending" | "in_review" | "reviewed";

export interface QueueRow {
  id: string;                           // identifiant pseudonymisé
  status: QueueStatus;
  matchScore: number;                   // 0..1
  confidence: "low" | "medium" | "high";
  receivedAt: string;                   // ISO date
}

export interface QueueTableProps {
  rows: QueueRow[] | null | undefined;
  n?: number | null;
  k?: number;
  onSelect?: (id: string) => void;
  traceLabel?: string;
}

export function QueueTable({ rows, n, k = 5, onSelect, traceLabel }: QueueTableProps) {
  const { t } = useTranslation();
  const sorted = useMemo(
    () => (rows ?? []).slice().sort((a, b) => b.matchScore - a.matchScore),
    [rows],
  );

  return (
    <SmallGroupGuard n={n} k={k} label={traceLabel}>
      <table className={styles.table} data-testid="queue-table">
        <thead>
          <tr>
            <th scope="col">{t("queue.id")}</th>
            <th scope="col">{t("queue.status")}</th>
            <th scope="col">{t("queue.matchScore")}</th>
            <th scope="col">{t("queue.confidence.label")}</th>
            <th scope="col">{t("queue.receivedAt")}</th>
            <th scope="col" aria-label={t("queue.actions")} />
          </tr>
        </thead>
        <tbody>
          {sorted.map((row) => (
            <tr key={row.id} data-testid={`queue-row-${row.id}`}>
              <td className={styles.id}>{row.id}</td>
              <td><span className={`${styles.status} ${styles[`status_${row.status}`]}`}>{t(`queue.statusValue.${row.status}`)}</span></td>
              <td>{(row.matchScore * 100).toFixed(0)}%</td>
              <td><span className={`${styles.badge} ${styles[`conf_${row.confidence}`]}`}>{t(`kpi.confidence.${row.confidence}`)}</span></td>
              <td>{row.receivedAt.slice(0, 10)}</td>
              <td>
                <button type="button" className={styles.action}
                  onClick={() => onSelect?.(row.id)}
                  aria-label={t("queue.open", { id: row.id })}>
                  {t("queue.open")}
                </button>
              </td>
            </tr>
          ))}
          {sorted.length === 0 && (
            <tr><td colSpan={6} className={styles.empty}>{t("queue.empty")}</td></tr>
          )}
        </tbody>
      </table>
    </SmallGroupGuard>
  );
}
EOF

write_file "$REPO_ROOT/src/widgets/QueueTable/QueueTable.module.css" <<'EOF'
.table{width:100%;border-collapse:collapse;font-size:.875rem}
.table th,.table td{text-align:left;padding:.625rem .75rem;border-bottom:1px solid var(--color-border,#e2e8f0)}
.table th{font-weight:600;color:var(--color-text-muted,#64748b);font-size:.75rem;text-transform:uppercase;letter-spacing:.02em}
.id{font-family:ui-monospace,SFMono-Regular,monospace;color:#475569}
.status,.badge{display:inline-block;padding:.125rem .5rem;border-radius:999px;font-size:.75rem;font-weight:600}
.status_pending{background:#e0e7ff;color:#3730a3}.status_in_review{background:#fef3c7;color:#92400e}.status_reviewed{background:#dcfce7;color:#166534}
.conf_low{background:#fee2e2;color:#991b1b}.conf_medium{background:#fef3c7;color:#92400e}.conf_high{background:#dcfce7;color:#166534}
.action{background:transparent;border:1px solid var(--color-border,#e2e8f0);border-radius:6px;padding:.25rem .5rem;cursor:pointer;font-size:.75rem}
.empty{text-align:center;color:var(--color-text-muted,#94a3b8);font-style:italic;padding:1.5rem}
EOF

write_file "$REPO_ROOT/src/widgets/QueueTable/index.ts" <<'EOF'
export { QueueTable } from "./QueueTable";
export type { QueueTableProps, QueueRow, QueueStatus } from "./QueueTable";
EOF

# ---------- AlertPanel ----------
write_file "$REPO_ROOT/src/widgets/AlertPanel/AlertPanel.tsx" <<'EOF'
// src/widgets/AlertPanel/AlertPanel.tsx — alertes qualité/gouvernance, jamais de citation nominative.
import { useTranslation } from "react-i18next";
import { SmallGroupGuard } from "../SmallGroupGuard";
import styles from "./AlertPanel.module.css";

export type AlertSeverity = "info" | "warning" | "critical";

export interface AlertItem {
  id: string;
  severity: AlertSeverity;
  messageKey: string;
  messageParams?: Record<string, string | number>;
  n?: number | null;
  ruleCode?: string;
}

export interface AlertPanelProps {
  alerts: AlertItem[] | null | undefined;
  k?: number;
  traceLabel?: string;
}

const ORDER: Record<AlertSeverity, number> = { critical: 0, warning: 1, info: 2 };

export function AlertPanel({ alerts, k = 5, traceLabel }: AlertPanelProps) {
  const { t } = useTranslation();
  const sorted = (alerts ?? []).slice().sort((a, b) => ORDER[a.severity] - ORDER[b.severity]);

  if (sorted.length === 0) {
    return <div className={styles.empty} data-testid="alert-panel-empty" role="status">{t("alerts.empty")}</div>;
  }

  return (
    <section className={styles.panel} data-testid="alert-panel" aria-label={t("alerts.title")} data-trace-label={traceLabel ?? ""}>
      <h3 className={styles.title}>{t("alerts.title")}</h3>
      <ul className={styles.list}>
        {sorted.map((a) => (
          <li key={a.id}
              className={`${styles.item} ${styles[`sev_${a.severity}`]}`}
              data-testid={`alert-${a.id}`}
              data-severity={a.severity}
              data-rule-code={a.ruleCode ?? ""}>
            <span className={styles.icon} aria-hidden="true">
              {a.severity === "critical" ? "⛔" : a.severity === "warning" ? "⚠️" : "ℹ️"}
            </span>
            <div className={styles.body}>
              <span className={styles.message}>{t(a.messageKey, a.messageParams)}</span>
              {a.ruleCode && <span className={styles.rule}>{a.ruleCode}</span>}
              {typeof a.n === "number" && a.n < k && (
                <SmallGroupGuard n={a.n} k={k} label={`alert:${a.id}`}><span /></SmallGroupGuard>
              )}
            </div>
          </li>
        ))}
      </ul>
    </section>
  );
}
EOF

write_file "$REPO_ROOT/src/widgets/AlertPanel/AlertPanel.module.css" <<'EOF'
.panel{display:flex;flex-direction:column;gap:.5rem}
.title{font-size:.875rem;font-weight:600;color:var(--color-text,#0f172a);margin:0}
.list{list-style:none;padding:0;margin:0;display:flex;flex-direction:column;gap:.5rem}
.item{display:flex;gap:.625rem;padding:.625rem .875rem;border-radius:8px;border-left:4px solid transparent;background:var(--color-bg-muted,#f8fafc)}
.sev_info{border-left-color:#0ea5e9;background:#f0f9ff}
.sev_warning{border-left-color:#f59e0b;background:#fffbeb}
.sev_critical{border-left-color:#dc2626;background:#fef2f2}
.icon{flex:0 0 auto}
.body{display:flex;flex-direction:column;gap:.125rem}
.message{font-size:.875rem;color:var(--color-text,#0f172a)}
.rule{font-family:ui-monospace,SFMono-Regular,monospace;font-size:.6875rem;color:var(--color-text-muted,#64748b)}
.empty{padding:1rem;text-align:center;color:var(--color-text-muted,#94a3b8);font-style:italic;font-size:.875rem}
EOF

write_file "$REPO_ROOT/src/widgets/AlertPanel/index.ts" <<'EOF'
export { AlertPanel } from "./AlertPanel";
export type { AlertPanelProps, AlertItem, AlertSeverity } from "./AlertPanel";
EOF

# ---------- Barrel widgets + i18n additions ----------
write_file "$REPO_ROOT/src/widgets/index.ts" <<'EOF'
// src/widgets/index.ts — barrel.
export * from "./SmallGroupGuard";
export * from "./KpiCard";
export * from "./QueueTable";
export * from "./AlertPanel";
EOF

write_file "$REPO_ROOT/src/widgets/README.md" <<'EOF'
# Widgets RGPD & Data (L2)

Composants présentationnels, sans fetch. Le data-fetching reste dans `src/pages/`.

## Invariants

- **RGPD** : tout agrégat passe par `SmallGroupGuard` (k=5 par défaut). Fail-closed.
- **Zéro PII** : aucun nom, email, téléphone. Seuls des IDs pseudonymisés.
- **Read-only** : aucun widget n'émet d'action de décision.
- **Traçabilité** : `data-suppressed-count`, `data-guard-k`, `data-rule-code` exposés pour audit.

## Composants

| Composant | Rôle | Gardé RGPD |
|---|---|---|
| `SmallGroupGuard` | Masque si n < k | — (c'est le garde) |
| `KpiCard` | Carte KPI | oui |
| `QueueTable` | File pseudonymisée | oui |
| `AlertPanel` | Alertes qualité | oui (par alerte) |
EOF

# ---------- Vérifs L2 ----------
section "L2 · Vérifications"

if [[ "$SKIP_BUILD" -eq 0 ]] && [[ -f "$REPO_ROOT/package.json" ]] && command -v npx >/dev/null 2>&1; then
  log "build front"
  run npx --yes tsc --noEmit
fi

if [[ "$SKIP_TESTS" -eq 0 ]] && [[ -f "$REPO_ROOT/package.json" ]] && command -v npx >/dev/null 2>&1; then
  log "tests widgets"
  run npx vitest run src/widgets --reporter=dot
fi

# Garde-fou PII : scan rapide des sources widgets
if command -v grep >/dev/null 2>&1; then
  log "scan PII heuristique sur src/widgets/"
  if grep -rEn '\b(email|phone|tel|ssn|iban|passport|birthdate)\b' "$REPO_ROOT/src/widgets/" 2>/dev/null; then
    warn "occurrence(s) suspecte(s) ci-dessus — vérifier manuellement"
  else
    ok "aucun pattern PII détecté"
  fi
fi

assert_no_out_of_scope "src/widgets/ src/i18n/"

print_summary "L2" "$PIVOT" "${#SUBS[@]}"

if [[ "$SKIP_PUSH" -eq 0 ]]; then
  section "L2 · Push"
  run "$LOTS_DIR/push-lot.sh" \
    --lot "$PIVOT" \
    --files "src/widgets/" \
    --message "feat(L2): widgets RGPD & data — small-group-guard + kpi-card + queue-table + alert-panel" \
    $( [[ "$DRY_RUN" -eq 0 ]] && echo "--yes" )
fi