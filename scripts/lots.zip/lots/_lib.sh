#!/usr/bin/env bash
# scripts/lots/_lib.sh — helpers partagés pour tous les scripts de lot.
# À sourcer : source "$(dirname "$0")/_lib.sh"

# ─── Couleurs ────────────────────────────────────────────────────
if [[ -t 1 ]]; then
  C_RED=$'\033[0;31m'; C_GRN=$'\033[0;32m'; C_YEL=$'\033[0;33m'
  C_BLU=$'\033[0;34m'; C_DIM=$'\033[2m';    C_RST=$'\033[0m'
else
  C_RED=""; C_GRN=""; C_YEL=""; C_BLU=""; C_DIM=""; C_RST=""
fi

# ─── Log avec préfixe de lot ─────────────────────────────────────
# LOT_TAG doit être défini par le script appelant (ex: "L1")
_LOT_TAG="${LOT_TAG:-lot}"

log()  { printf '%s[%s]%s %s\n' "$C_BLU" "$_LOT_TAG" "$C_RST" "$*"; }
ok()   { printf '%s[ok ]%s %s\n'  "$C_GRN" "$C_RST" "$*"; }
warn() { printf '%s[wrn]%s %s\n'  "$C_YEL" "$C_RST" "$*" >&2; }
dry()  { printf '%s[dry]%s %s\n'  "$C_DIM" "$C_RST" "$*"; }
die()  { printf '%s[err]%s %s\n'  "$C_RED" "$C_RST" "$*" >&2; exit 1; }

# ─── Charger les options standard ────────────────────────────────
# Définit : DRY_RUN, NO_PUSH, NO_PROPAGATE, NO_TESTS, ASSUME_YES
parse_common_args() {
  DRY_RUN=0; NO_PUSH=0; NO_PROPAGATE=0; NO_TESTS=0; ASSUME_YES=0
  while [[ $# -gt 0 ]]; do
    case "$1" in
      --dry-run)      DRY_RUN=1; shift ;;
      --no-push)      NO_PUSH=1; shift ;;
      --no-propagate) NO_PROPAGATE=1; shift ;;
      --no-tests)     NO_TESTS=1; shift ;;
      --yes|-y)       ASSUME_YES=1; shift ;;
      -h|--help)      return 1 ;;
      *) printf 'unexpected arg: %s\n' "$1" >&2; exit 1 ;;
    esac
  done
  return 0
}

# ─── write : écrit un fichier (dry-run aware) ────────────────────
# Usage : write <path> <<'EOF' ... EOF
write() {
  local path="$1"
  if [[ "${DRY_RUN:-0}" == "1" ]]; then
    dry "would write $path"
    cat >/dev/null
    return 0
  fi
  mkdir -p "$(dirname "$path")"
  cat > "$path"
  ok "wrote $path"
}

# ─── append : ajoute une ligne à un fichier (idempotent) ─────────
append_line() {
  local file="$1" line="$2"
  [[ "${DRY_RUN:-0}" == "1" ]] && { dry "append '$line' to $file"; return 0; }
  touch "$file"
  if ! grep -qxF "$line" "$file"; then
    printf '%s\n' "$line" >> "$file"
  fi
}

# ─── copy_from_branch : copie un fichier d'une branche vers le cwd ─
copy_from_branch() {
  local branch="$1" src_path="$2" dst_path="$3"
  if [[ "${DRY_RUN:-0}" == "1" ]]; then
    dry "would copy $branch:$src_path → $dst_path"
    return 0
  fi
  if git cat-file -e "$branch:$src_path" 2>/dev/null; then
    mkdir -p "$(dirname "$dst_path")"
    git show "$branch:$src_path" > "$dst_path"
    ok "copied $src_path from $branch"
    return 0
  fi
  return 1
}

# ─── ensure_clean_tree : refuse de travailler sur dirty ──────────
ensure_clean_tree() {
  [[ "${DRY_RUN:-0}" == "1" ]] && return 0
  if [[ -n "$(git status --porcelain)" ]]; then
    warn "working tree dirty:"
    git status --short | sed 's/^/     /'
    die "commit or stash before running"
  fi
}

# ─── checkout_or_create : se place sur la branche ou la crée ─────
checkout_or_create() {
  local branch="$1" base="${2:-main}"
  if git show-ref --verify --quiet "refs/heads/$branch"; then
    [[ "${DRY_RUN:-0}" == "1" ]] || git checkout "$branch"
    ok "checked out local $branch"
  elif git ls-remote --exit-code --heads origin "$branch" >/dev/null 2>&1; then
    [[ "${DRY_RUN:-0}" == "1" ]] || git checkout -B "$branch" "origin/$branch"
    ok "checked out remote $branch"
  else
    warn "branch $branch not found — creating from $base"
    [[ "${DRY_RUN:-0}" == "1" ]] || git checkout -B "$branch" "$base"
    ok "created $branch from $base"
  fi
}

# ─── commit_and_push : commit + push de la branche courante ──────
commit_and_push() {
  local msg="$1" files="$2" branch
  branch="$(git branch --show-current)"

  if [[ -z "$(git status --porcelain)" ]]; then
    log "nothing to commit"
    return 0
  fi

  # shellcheck disable=SC2086
  git add $files 2>/dev/null || git add -A

  git -c user.name="AbirhaouiSalah" \
      -c user.email="sabirhaouipro@gmail.com" \
      commit -m "$msg"
  ok "committed on $branch"

  if [[ "${NO_PUSH:-0}" != "1" ]]; then
    git push -u origin "HEAD:refs/heads/$branch"
    ok "pushed $branch"
  else
    warn "skip push (--no-push)"
  fi
}

# ─── propagate_to : délègue à scripts/git/propagate.sh ──────────
propagate_to() {
  local files="$1" msg="$2"
  [[ "${NO_PROPAGATE:-0}" == "1" ]] && { warn "skip propagation (--no-propagate)"; return 0; }

  local prop="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)/git/propagate.sh"
  if [[ -x "$prop" ]]; then
    "$prop" --files "$files" --message "$msg" --yes || warn "propagation issues (non-blocking)"
  else
    warn "propagate.sh not found at $prop"
  fi
}

# ─── run_tests : lance typecheck + tests + i18n ─────────────────
run_tests() {
  [[ "${NO_TESTS:-0}" == "1" ]] && { warn "skip tests (--no-tests)"; return 0; }
  [[ "${DRY_RUN:-0}" == "1" ]] && return 0
  command -v pnpm >/dev/null 2>&1 || { warn "pnpm absent — skip tests"; return 0; }

  log "typecheck"; pnpm typecheck 2>&1 | tail -5 || warn "typecheck issues"
  log "tests";     pnpm test -- --run 2>&1 | tail -8 || warn "test issues"
  log "i18n";      pnpm test:i18n 2>&1 | tail -3 || warn "i18n issues"
}
